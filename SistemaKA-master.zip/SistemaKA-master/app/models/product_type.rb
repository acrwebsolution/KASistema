class ProductType < ActiveRecord::Base
  has_many :products
end
