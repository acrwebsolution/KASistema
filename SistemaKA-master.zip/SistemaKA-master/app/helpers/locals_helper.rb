module LocalsHelper
end
