require 'test_helper'

class MusicalOrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
