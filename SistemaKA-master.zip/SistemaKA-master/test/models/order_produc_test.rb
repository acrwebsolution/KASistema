require 'test_helper'

class OrderProducTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
